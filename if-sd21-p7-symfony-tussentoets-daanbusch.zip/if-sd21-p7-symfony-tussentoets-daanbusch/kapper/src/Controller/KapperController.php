<?php

namespace App\Controller;

use App\Entity\Treatment;
use Doctrine\Persistence\ManagerRegistry;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\Routing\Annotation\Route;

class KapperController extends AbstractController
{
    #[Route('/', name: 'Kapper')]
    public function Kapper(ManagerRegistry $doctrine): \Symfony\Component\HttpFoundation\Response
    {
        $treatment = $doctrine->getRepository(Treatment::class)->findAll();
        //dd($treatment);
        return $this->render('home.html.twig', ['treatment' => $treatment]);
    }
}